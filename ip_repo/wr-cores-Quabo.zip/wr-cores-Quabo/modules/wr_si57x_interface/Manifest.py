files = ["si570_if_wbgen2_pkg.vhd",
			   "si570_if_wb.vhd",
				 "wr_si57x_interface.vhd",
				 "xwr_si57x_interface.vhd"]

