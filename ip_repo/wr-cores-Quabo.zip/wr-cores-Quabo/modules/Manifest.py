modules =  {
    "local" : [
        "fabric",
        "wr_tbi_phy",
        "timing",
        "wr_mini_nic",
        "wr_softpll_ng",
        "wr_endpoint",
        "wr_pps_gen",
        "wr_dacs",
        "wr_si57x_interface",
        "wr_eca",
        "wr_tlu",
        "wrc_core",
        "wr_streamers",
    ]
}
