files = [	"enc_8b10b.vhd",
                "wr_tbi_phy.vhd",
                "disparity_gen_pkg.vhd" ];
