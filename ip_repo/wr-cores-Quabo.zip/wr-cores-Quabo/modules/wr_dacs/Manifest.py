files = [
  "spec_serial_dac_arb.vhd",
  "spec_serial_dac.vhd"
]
