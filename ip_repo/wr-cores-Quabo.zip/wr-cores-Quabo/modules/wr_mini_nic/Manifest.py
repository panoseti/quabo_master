files = [ "minic_packet_buffer.vhd",
          "minic_wb_slave.vhd",
          "minic_wbgen2_pkg.vhd",
          "wr_mini_nic.vhd",
          "xwr_mini_nic.vhd" ];
