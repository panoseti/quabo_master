files = ["wr_fabric_pkg.vhd", "xwb_fabric_sink.vhd", "xwb_fabric_source.vhd", "xwrf_mux.vhd", "xwrf_reg.vhd",
    "xwrf_loopback/lbk_pkg.vhd", "xwrf_loopback/lbk_wishbone_controller.vhd",
    "xwrf_loopback/xwrf_loopback.vhd", "xwrf_loopback/wrf_loopback.vhd" ];
