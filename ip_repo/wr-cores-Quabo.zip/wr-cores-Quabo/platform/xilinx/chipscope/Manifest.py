files =["chipscope_icon.ngc",  "chipscope_ila.ngc" ]
