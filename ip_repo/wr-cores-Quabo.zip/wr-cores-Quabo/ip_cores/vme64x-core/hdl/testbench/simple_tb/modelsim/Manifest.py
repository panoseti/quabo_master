action = "simulation"
sim_tool = "modelsim"
sim_top = "top_tb"

# for general-cores
target = None

modules = {
    "local": [ ".." ],
}
