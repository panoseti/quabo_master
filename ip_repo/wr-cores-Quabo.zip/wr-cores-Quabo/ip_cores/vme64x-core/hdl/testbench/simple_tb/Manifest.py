files = [
 "top_tb.vhd",
]

modules = {
    "local": [ "../../rtl", "../../ip_cores/general-cores" ],
}
