files = ["gn4124_core.vhd",
         "gn4124_core_pkg.vhd",
         "l2p_ser.vhd",
         "p2l_des.vhd"]
