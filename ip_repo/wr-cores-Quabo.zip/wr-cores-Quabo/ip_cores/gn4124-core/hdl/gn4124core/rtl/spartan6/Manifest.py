files = ["gn4124_core.vhd",
         "gn4124_core_pkg.vhd",
         "l2p_ser.vhd",
         "p2l_des.vhd",
         "serdes_1_to_n_clk_pll_s2_diff.vhd",
         "serdes_1_to_n_data_s2_se.vhd",
         "serdes_n_to_1_s2_diff.vhd",
         "serdes_n_to_1_s2_se.vhd",
         "pulse_sync_rtl.vhd"]
