files = ["mem_model.vhd"]

vcom_opt = "-87"
