if target=="xilinx":
  modules = {"local" : ["hdl/gn4124core/rtl"]}
