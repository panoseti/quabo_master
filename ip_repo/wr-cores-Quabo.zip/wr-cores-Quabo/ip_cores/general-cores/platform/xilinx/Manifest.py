modules = { 
  "local" : [
     "wb_xilinx_fpga_loader",
     "wb_xil_multiboot"
  ]
}
