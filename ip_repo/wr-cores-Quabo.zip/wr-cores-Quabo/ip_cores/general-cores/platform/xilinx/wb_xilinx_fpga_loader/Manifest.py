files = [
"wb_xilinx_fpga_loader.vhd",
"xwb_xilinx_fpga_loader.vhd",
"xloader_registers_pkg.vhd",
"xloader_wb.vhd"];
