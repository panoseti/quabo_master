if target=="altera":
	modules = {"local" : "altera"}
elif target=="xilinx":
	modules = {"local" : "xilinx"}