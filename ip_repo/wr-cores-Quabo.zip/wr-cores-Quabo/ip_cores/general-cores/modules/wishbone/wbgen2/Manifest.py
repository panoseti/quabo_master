files = ["wbgen2_dpssram.vhd",
				"wbgen2_eic.vhd",
				"wbgen2_fifo_async.vhd",
				"wbgen2_fifo_sync.vhd",
				"wbgen2_pkg.vhd"]

#library = "wbgen2"
