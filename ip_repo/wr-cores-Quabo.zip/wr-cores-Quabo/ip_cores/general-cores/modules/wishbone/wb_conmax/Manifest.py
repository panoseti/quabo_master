files = ["wb_conmax_pri_dec.vhd", "wb_conmax_pri_enc.vhd", "wb_conmax_arb.vhd", "wb_conmax_msel.vhd",
					"wbconmax_pkg.vhd", "wb_conmax_slave_if.vhd", "wb_conmax_master_if.vhd", "wb_conmax_rf.vhd",
					"xwb_conmax.vhd" ];
