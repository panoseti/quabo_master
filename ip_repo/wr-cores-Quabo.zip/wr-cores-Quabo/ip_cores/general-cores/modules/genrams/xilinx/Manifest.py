files = [
"generic_dpram.vhd",
"generic_dpram_sameclock.vhd",
"generic_dpram_dualclock.vhd",
"generic_simple_dpram.vhd",
"generic_dpram_split.vhd",
"generic_spram.vhd",
"gc_shiftreg.vhd"]

