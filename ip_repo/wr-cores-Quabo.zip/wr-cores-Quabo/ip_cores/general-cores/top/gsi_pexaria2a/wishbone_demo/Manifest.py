files = ["wishbone_demo_top.vhd", "sys_pll.vhd"]

modules = {
    "local" : ["../../../" ]
    }
