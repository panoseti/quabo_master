Type 'make' to create your .pdf documentation file.

You need Inkscape to make the documentation files:
sudo apt-get install inkscape