modules = {
    "local" : [
	"modules/common",
	"modules/genrams",
	"modules/wishbone",
	"platform"
    ]
}
