files = [
    "wr_vfchd_pkg.vhd",
    "xwrc_board_vfchd.vhd",
    "wrc_board_vfchd.vhd",
    "sfp_i2c_adapter.vhd",
]

modules = {
    "local" : [
        "../common",
    ]
}
