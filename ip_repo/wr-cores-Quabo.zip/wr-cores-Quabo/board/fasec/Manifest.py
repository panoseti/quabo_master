files = [
    "wr_fasec_pkg.vhd",
    "xwrc_board_fasec.vhd",
    "wrc_board_fasec.vhd",
    "wrc_board_fasec_ip.xdc"
]

modules = {
    "local" : [
        "../common",
    ]
}
