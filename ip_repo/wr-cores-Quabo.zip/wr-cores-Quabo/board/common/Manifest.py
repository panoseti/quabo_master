files = [
    "wr_board_pkg.vhd",
    "xwrc_board_common.vhd",
]
