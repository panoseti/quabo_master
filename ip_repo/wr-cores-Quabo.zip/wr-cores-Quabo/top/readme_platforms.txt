Available device plaftorms (so far):
------------------------------------

gsi_scu - GSI's Scalable Control Unit (SCU), based on Altera ArriaII-GX (EP2AGX125)
spec_1_1 - CERN's Simple PCI-Express Carrier (SPEC), based on Xilinx Spartan-6 (XC6SLX45). Version 1.1 or newer (pin-compatible)
