files = ["spec_top.vhd", "spec_top.ucf", "spec_reset_gen.vhd","timestamp_adder.vhd"  ]

modules = { "local" : ["../../../", "../../../platform/xilinx/chipscope"] }